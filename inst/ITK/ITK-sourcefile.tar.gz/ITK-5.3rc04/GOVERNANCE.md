# ITK Project Governance

Please visit the [Insight Software Consortium website](https://www.insightsoftwareconsortium.org/)
to learn about the bylaws that govern ITK.
